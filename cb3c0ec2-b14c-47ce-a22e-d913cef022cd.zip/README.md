# Ansys Lumerical (optics / FDTD) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: ansys-lumerical-core
* top-level import: ansys.lumerical
* kind: grpc
* env: ANSYS_ROOT
